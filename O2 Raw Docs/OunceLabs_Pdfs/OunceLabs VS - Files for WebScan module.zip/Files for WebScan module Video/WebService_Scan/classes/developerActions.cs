﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;
using o2.core;
using o2.core.zip.classes;
using System.Collections.Generic;
using o2.rules;

namespace o2.webservice_scan.classes
{
    public class developerActions
    {
        public static void processUploadedFiles(HttpRequest hrHttpRequest)
        {
            processUploadedFiles(hrHttpRequest, false);
        }
        public static void processUploadedFiles(HttpRequest hrHttpRequest, bool bCopyDirectlyToScanFolder)
        {
            foreach (String sCtrlKey in hrHttpRequest.Files)
            {
                HttpPostedFile hpfHttpPostedFile = hrHttpRequest.Files[sCtrlKey];
                String sLocalFilename = Path.Combine(
                    (bCopyDirectlyToScanFolder) ? config.getScanRequestsFolder() : config.getDevelopersUploadedApplicationsFolder()
                    , Path.GetFileName(hpfHttpPostedFile.FileName));
                if (Directory.Exists(sLocalFilename) == false)
                    hpfHttpPostedFile.SaveAs(sLocalFilename);                                            
            }
        }

        public static string getTableWithUploadedApplications()
        {
           
            String sHtmlTableBegin= "<Table border=1>";
            String sTableHeader = "<tr><td><b>FileName </b></td><td><b>Size</b></td><td><b>Can File Be Scanned?</b></td><td><b>CirDataFile</b></td></tr>";
            String sRows = "";
            foreach(String sFile in Files.getFilesFromDir_returnFullPath( config.getDevelopersUploadedApplicationsFolder()))
            {
                String sRow = "<tr>";
                FileInfo fsiFileSystemInfo = new FileInfo(sFile);
                sRow += "<td>" + fsiFileSystemInfo.Name + "</td><td>" + fsiFileSystemInfo.Length + "</td><td>" + canFileBeScannedTableCell(fsiFileSystemInfo.Name) + "</td><td>" + getLinkToDownloadCirDataFile(fsiFileSystemInfo.Name) + "</td>";
                sRow += "</tr>";
                sRows += sRow;
            }
            String sHtmlTableEnd= "</Table>";
            return sHtmlTableBegin + sTableHeader + sRows +  sHtmlTableEnd;
        }
        public static String getLinkToRequestScan(String sFileToRequestScan)
        {
            return string.Format("<a target=" + config.getActionsLogIFrameName() + " href='developer.aspx?action=RequestScan&filename={0}'>Request Scan</a>", sFileToRequestScan);
        }

        public static String getLinkToDownloadCirDataFile(String sFileUploaded)
        {
            String sCirDataFile = findCirDataFileOnUploadedFileFolder(sFileUploaded);
            if (File.Exists(sCirDataFile))
            {
                String sLinkToCirData = sCirDataFile.Replace(AppDomain.CurrentDomain.BaseDirectory, "");
                return string.Format("<a href='../{0}'>{1}</a>", sLinkToCirData, Path.GetFileName(sCirDataFile));
            }
            else
                return "";
           
        }
        public static String canFileBeScannedTableCell(String sFileToCheck)
        {
            if (Path.GetExtension(sFileToCheck).ToLower() != ".zip")
                return "<a target=" + config.getActionsLogIFrameName() + " href='Developer.aspx?action=DeleteFile&fileName=" + sFileToCheck + "'>File must be zip, delete file</a>";

            String sCirDataFile = findCirDataFileOnUploadedFileFolder(sFileToCheck);
           // return "cir: " + sCirDataFile;
            if (File.Exists(sCirDataFile))
                return "Yes All OK " + getLinkToRequestScan(sFileToCheck);
            else
                return "<a target=" + config.getActionsLogIFrameName()+" href='Developer.aspx?action=TestIfFileCanBeScanned&fileName=" + sFileToCheck + "'>Test now</a>";                                    
        }

        public static String findCirDataFileOnUploadedFileFolder(String sUploadedFile)
        { 
            String sTargetFolder = Path.Combine(config.getDevelopersUploadedApplicationsFolder(), Path.GetFileNameWithoutExtension(sUploadedFile));            
            List<String> lsCirDataFiles = new List<string>();
            Files.getListOfAllFilesFromDirectory(lsCirDataFiles, sTargetFolder, true, "*.CirData", false);
           // return lsCirDataFiles.Count.ToString();
            if (lsCirDataFiles.Count > 1)
                return "More than 1 *.cirdata file was found in the zip file uploaded (one 1 *.cirdata per zip file is supported";
            else if (lsCirDataFiles.Count == 1)
                return lsCirDataFiles[0];
            return "";
        }
    /*    public static String calculateCirDataFileFromUploadedFile(String sUploadedFile)
        {
            return String.Format("{0}/{1}/{1}.CirData", config.getScanResultsFolder(), Path.GetFileNameWithoutExtension(sUploadedFile));
        }*/

        public static void processAction(String sAction, String sFileName,HttpResponse hrHttpResponse)
        {            
            scanproxy.redirectO2DebugToResponseStream(hrHttpResponse);
            switch (sAction)
            {
                case "DeleteFile":
                    DeleteFile(sFileName);
                    break;
                case "TestIfFileCanBeScanned":
                    TestIfFileCanBeScanned(sFileName);
                    break;
                case "RequestScan":
                    RequestScan(sFileName);
                    break;
                default:
                    DebugMsg._Error("Unrecognized Action: " + sAction);
                    break;
            }
            hrHttpResponse.End();
        }        

        public static void RequestScan(String sFileName)
        {           
            String sSourceFolder = Path.Combine(config.getDevelopersUploadedApplicationsFolder(), Path.GetFileNameWithoutExtension(sFileName));
            String sSourceFile = Path.Combine(config.getDevelopersUploadedApplicationsFolder(), Path.GetFileName(sFileName));
            //String sTargetFile = Path.Combine(config.getScanRequestsFolder(), sFileName + " with CirData.zip");
            String sTargetFile = Path.Combine(config.getScanRequestsFolder(), sFileName);
            Files.deleteFile(sTargetFile);            
            zipUtils.zipFolder(sSourceFolder, sTargetFile);
            Files.deleteFolder(sSourceFolder);
            Files.deleteFile(sSourceFile); 
            DebugMsg._Debug("Zipped Scan Request into :{0}", Path.GetFileNameWithoutExtension(sTargetFile));
        }

        public static void DeleteFile(String sFileToDelete)
        {
         
            foreach (String sFile in Files.getFilesFromDir_returnFullPath(config.getDevelopersUploadedApplicationsFolder()))
            {                
                if (Path.GetFileName(sFile) == sFileToDelete)
                {
                    File.Delete(sFile);
                    DebugMsg._Debug("Deleted File:" + sFileToDelete);
                }
            }
            DebugMsg._Error("Could not find find to delete..");
        }

        public static void TestIfFileCanBeScanned(String sFileToTest)
        {
            sFileToTest = Path.Combine(config.getDevelopersUploadedApplicationsFolder(), sFileToTest);

            scanproxy.redirectO2DebugToResponseStream(HttpContext.Current.Response);
            scanproxy scScanProxy = new scanproxy();                                 
            DebugMsg._Debug("To test if the file can be scanned we are going to try to scan the file with no rules and just create the CirDump");
            String sTargetFolder = Path.Combine(config.getDevelopersUploadedApplicationsFolder(), Path.GetFileNameWithoutExtension(sFileToTest));
            String sApplicationToScan = scan.ProcessZipFileAndGetApplicationFileToScan(sFileToTest, sTargetFolder);
            if (sApplicationToScan != "")
                scan.CreateCirDump(sApplicationToScan, sTargetFolder);            
            DebugMsg._Debug("Test completed");
        }

        public static String getListWithScanRequests()
        {
            String sScanRequest = "<ul>";
            foreach (String sFile in Files.getFilesFromDir(config.getScanRequestsFolder()))
                sScanRequest += "<li>" + sFile + "</li>";
            sScanRequest += "</ul>";
            return sScanRequest;        
        }

        public static String getListWithScanResults()
        {
            String sScanRequest = "<ul>";
            foreach (String sFolder in Directory.GetDirectories(config.getDevelopersPublishResultsFolder()))
            {
                String sPublishedFiles = securityConsultantActions.getLinksForPublishedFiles(Path.GetFileName(sFolder));
                if (sPublishedFiles != "<ul></ul>")
                    sScanRequest += "<li><b>" + Path.GetFileName(sFolder) + "</b>" + sPublishedFiles + "</li>";
            }
            sScanRequest += "</ul>";
            return sScanRequest;
        }
        
        
        //
    }
}
