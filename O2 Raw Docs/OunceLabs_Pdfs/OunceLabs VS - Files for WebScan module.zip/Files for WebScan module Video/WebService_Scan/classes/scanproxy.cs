﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;
using o2.core;
using o2.rules;

namespace o2.webservice_scan.classes
{
    public class scanproxy
    {

        public static void redirectO2DebugToResponseStream(HttpResponse hrHttpResponse)
        {
            hrHttpResponse.Flush();
            hrHttpResponse.BufferOutput = false;
            DebugMsg.sOutputStream = hrHttpResponse.OutputStream;
            DebugMsg.sShowStreamWithHtmlFormating = true;
            DebugMsg.bLogCache = true;
        }

        public string scanApplication(String sApplicationToScan, HttpResponse hrHttpResponse)
        {
            // config stuff to be able to use webservice output
            redirectO2DebugToResponseStream(hrHttpResponse);
            // Scan App
            try
            {
                String sScanResultsFolder = config.getScanResultsFolder();
                sScanResultsFolder = Path.Combine(sScanResultsFolder, Path.GetFileNameWithoutExtension(sApplicationToScan));
                DebugMsg._Debug("Project Files will be saved on :{0}", sScanResultsFolder);

                //if (ScanWithExistingRules(sApplicationToScan,sScanResultsFolder))
                if (scan.ScanWithNoRules(sApplicationToScan, sScanResultsFolder))
                    //if (createCirDump(sApplicationToScan, sScanResultsFolder))
                    if (scan.ScanWithSelectedAutomaticRuleSets(sApplicationToScan, sScanResultsFolder, true, false, false, "bCallBacksOnControlFlowGraphs_And_ExternalSinks"))
                        if (scan.ScanWithSelectedAutomaticRuleSets(sApplicationToScan, sScanResultsFolder, false, true, false, "bCallBacksOnEdges_And_ExternalSinks"))
                            if (scan.ScanWithSelectedAutomaticRuleSets(sApplicationToScan, sScanResultsFolder, false, false, true, "bSourcesAndSinks"))
                            { }

                //createCirDumpAndScanWithAllRules(sApplicationToScan, sScanResultsFolder);

            }
            catch (Exception ex)
            {
                DebugMsg._Error("in scanProxy.scanApplication:{0}", ex.Message);
            }
            DebugMsg._Debug("All done");
            hrHttpResponse.End();
            return "Scannign Application :{0}" + sApplicationToScan;

        }   
    }
}
