﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using o2.core;
using System.IO;
using o2.core.zip.classes;
using o2.rules;

namespace o2.webservice_scan.classes
{    
    public class securityConsultantActions
    {
        static String sActionsPage = "SecurityConsultant.aspx";
        public enum actions
        {
            ScanUsingExistingRules,
            CreateCirDataFile,
            ScanWithCallBacksAndSinks,
            ScanWithAllCirDrivenRules,
            DeleteFile,
            PublishFile
        }

        public static void processUploadedFiles(HttpRequest hrHttpRequest)
        {
            foreach (String sCtrlKey in hrHttpRequest.Files)
            {
                HttpPostedFile hpfHttpPostedFile = hrHttpRequest.Files[sCtrlKey];
                String sLocalFilename = Path.Combine(config.getScanResultsFolder(),hrHttpRequest["ctl00$ContentPlaceHolder1$ddlTargetProject"]);
                //HttpContext.Current.Response.Write("<hr/>" + hrHttpRequest.Form["ctl00$ContentPlaceHolder1$ddlTargetProject"] + "<hr/>");
                sLocalFilename = Path.Combine(sLocalFilename, Path.GetFileName(hpfHttpPostedFile.FileName));                
                hpfHttpPostedFile.SaveAs(sLocalFilename);       
            }                   
        }

        public static void processAction(String sAction, String sFileName, HttpResponse hrHttpResponse)
        {
            //scanproxy scScanProxy = new scanproxy();
            scanproxy.redirectO2DebugToResponseStream(hrHttpResponse);
            DebugMsg._Debug("Processing action:{0} on file {1}", sAction, sFileName);
            switch (sAction)
            {
                case "ScanUsingExistingRules":
                    ActionCreateCirDataFile(sFileName,actions.ScanUsingExistingRules);
                    break;
                case "CreateCirDataFile":
                    ActionCreateCirDataFile(sFileName,actions.CreateCirDataFile);
                    break;
                case "ScanWithCallBacksAndSinks":
                    ActionCreateCirDataFile(sFileName, actions.ScanWithCallBacksAndSinks);
                    break;
                case "ScanWithAllCirDrivenRules":
                    ActionCreateCirDataFile(sFileName, actions.ScanWithAllCirDrivenRules);
                    break;
                case "DeleteFile":
                    ActionDeleteFile(sFileName);
                    break;
                case "PublishFile":
                    ActionPublishFile(sFileName);
                    break;
                default:
                    DebugMsg._Error("Unrecognized Action: " + sAction);
                    break;
            }            
            hrHttpResponse.End();
        }

        public static void ActionPublishFile(String sFileName)
        {            
            String sTargetFolder = Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(config.getDevelopersPublishResultsFolder(), Path.GetFileNameWithoutExtension(Path.GetDirectoryName(sFileName))));            
            String sTargetFile = Path.Combine(sTargetFolder,Path.GetFileName(sFileName));
            Files.MoveFile(sFileName, sTargetFile);
            DebugMsg._Debug("File copied to: {0}", sTargetFile);
        }

        public static void ActionCreateCirDataFile(String sTargetFile, actions aAction)
        {            
            scanproxy scScanProxy = new scanproxy();            
            sTargetFile = Path.Combine(config.getScanRequestsFolder(), sTargetFile);
            String sFolderToUnzipFiles = Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(config.getScanRequestsFolder(), Path.GetFileNameWithoutExtension(sTargetFile)));
            String sFolderToPlaceResultFiles = Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(config.getScanResultsFolder(), Path.GetFileNameWithoutExtension(sTargetFile)));
            String sApplicationToScan = scan.ProcessZipFileAndGetApplicationFileToScan(sTargetFile, sFolderToUnzipFiles);
            
            if (sApplicationToScan != "")
            {
                switch (aAction.ToString())
                {
                    case "ScanUsingExistingRules":
                        scan.ScanWithExistingRules(sApplicationToScan, sFolderToPlaceResultFiles);
                        break;
                    case "CreateCirDataFile":
                        scan.CreateCirDump(sApplicationToScan, sFolderToPlaceResultFiles);
                        break;
                    case "ScanWithCallBacksAndSinks":
                        scan.ScanWithSelectedAutomaticRuleSets(sApplicationToScan, sFolderToPlaceResultFiles, true, false, false, " ScanWithCallBacksAndSinks");
                        break;
                    case "ScanWithAllCirDrivenRules":
                        scan.ScanWithSelectedAutomaticRuleSets(sApplicationToScan, sFolderToPlaceResultFiles, true, true, true, " ScanWithAllCirDrivenRules");
                        break;
                        
                }
                String sCirDataInResultsFolder = Path.Combine(sFolderToPlaceResultFiles, Path.GetFileName(sApplicationToScan) + ".CirData");
                if (false == File.Exists(sCirDataInResultsFolder) && File.Exists(sApplicationToScan + ".CirData"))
                    File.Copy(sApplicationToScan + ".CirData", sCirDataInResultsFolder);
                CreateZipWithScansData(sFolderToPlaceResultFiles);
            }
            Files.deleteFolder(sFolderToUnzipFiles);
        }

        public static void CreateZipWithScansData(String sFolderToPlaceResultFiles)
        {
            String sZipFileName = Path.Combine(sFolderToPlaceResultFiles, Path.GetFileNameWithoutExtension(sFolderToPlaceResultFiles)+"_AllFiles.zip");
            File.Delete(sZipFileName);
            zipUtils.zipFolder(sFolderToPlaceResultFiles,sZipFileName);
        }
        public static void ActionDeleteFile(String sTargetFile)
        {
            String sFileToDelete = Path.Combine(config.getScanRequestsFolder(), sTargetFile);
            if (File.Exists(sFileToDelete))
                Files.deleteFile(sFileToDelete);
            DebugMsg._Info("Deleted file {0}", sTargetFile);
        }

        public static string getTableWithApplicationsToScan()
        {
            return getTableWithApplicationsToScan(false);
        }

        public static string getTableWithApplicationsToScan(bool bSimpleMode)
        {             
            String sHtmlTableBegin = "<Table border=1>";
            String sTableHeader = "<tr>" +
                                        "<td><b>Application To Scan </b></td>" +
                                        "<td><b>File Size</b></td>" +
                                         "<td><b>Actions</b></td>" +
                                         "<td><b>Results</b></td>" +
                                         "<td><b>Published Files</b></td>" + 
                                        /* "<td><b>Scan Using Existing Rules</b></td>" +
                                        "<td><b>Create Cir Dump</b></td>" +
                                        "<td><b>Scan with Rules: Callbacks on CFG and External Sinks</b></td>" +
                                        "<td><b>Scan with CirDriven Rules</b></td>" +*/
                                   "</tr>";
            String sRows = "";
            foreach (String sFile in Files.getFilesFromDir_returnFullPath(config.getScanRequestsFolder()))
            {
                String sRow = "<tr>";
                FileInfo fsiFileSystemInfo = new FileInfo(sFile);
                sRow += "<td>" + fsiFileSystemInfo.Name + "</td><td>" + fsiFileSystemInfo.Length + "</td>" +
                        "<td>" + getLinksWithActionsForFile(fsiFileSystemInfo.Name,bSimpleMode)+ "</td>" + 
                        "<td>" + getLinksForScanResultsFiles(fsiFileSystemInfo.Name,true) + "</td>" +
                        "<td>" + getLinksForPublishedFiles(fsiFileSystemInfo.Name) + "</td>";
                sRow += "</tr>";
                sRows += sRow;
            }
            String sHtmlTableEnd = "</Table>";
            return sHtmlTableBegin + sTableHeader + sRows + sHtmlTableEnd;
        }
        
        //    CreateCirDataFile,
        //    ScanWithCallBacksAndSinks,
        //    ScanWithAllCirDrivenRules

        public static string getLinksForPublishedFiles(String sTargetFile)
        {            
            String sScanResultsFolder = Path.Combine(config.getDevelopersPublishResultsFolder(), Path.GetFileNameWithoutExtension(sTargetFile));            
            String sScanResults = "<ul>";
            foreach (String sFile in Files.getFilesFromDir_returnFullPath(sScanResultsFolder))
            {
                String sRelativePathToFile = "../" + sFile.Replace(AppDomain.CurrentDomain.BaseDirectory, "");
                sScanResults += "<li>" +
                    getLink(sRelativePathToFile, Path.GetFileName(sFile)) +
               //     "  -  [" + getLinkForAction(sActionsPage, actions.PublishFile.ToString(), sFile, "Publish") + "] " +
                  " " + getLinkForAction(sActionsPage, actions.DeleteFile.ToString(), sFile, "<font color='gray'>del</font>") + "" + 
                    "</li>";
            }
            sScanResults += "</ul>";
            return sScanResults;
        }

        public static string getLinksForScanResultsFiles(String sTargetFile, bool bShowPublishButton)
        { 
            String sScanResultsFolder = Path.Combine(config.getScanResultsFolder(), Path.GetFileNameWithoutExtension(sTargetFile));                
            String sScanResults = "<ul>";
            foreach(String sFile in Files.getFilesFromDir_returnFullPath(sScanResultsFolder))
            {
                String sRelativePathToFile = "../" + sFile.Replace(AppDomain.CurrentDomain.BaseDirectory,"");
                sScanResults += "<li>" + 
                    getLink(sRelativePathToFile, Path.GetFileName(sFile)) +
                    ((bShowPublishButton) ? " - " + getLinkForAction(sActionsPage, actions.PublishFile.ToString(), sFile, "<font color='green'><b>Publish</b></font>") : "") +   
                    " - " + getLinkForAction(sActionsPage, actions.DeleteFile.ToString(), sFile, "<font color='gray'>del</font>") + "" + 
                    "</li>";
            }
           sScanResults += "</ul>";
            return sScanResults;
        }

        public static String getLinksWithActionsForFile(String sTargetFile)
        {
            return getLinksWithActionsForFile(sTargetFile, false);
        }

        public static String getLinksWithActionsForFile(String sTargetFile, bool bSimpleMode)
        {
            String sActions =   "<ul>" +
                                "<li>" + getLinkForAction(sActionsPage, actions.ScanUsingExistingRules.ToString(), sTargetFile, "Scan using existing rules") + "</li>";
            if (bSimpleMode == false)
            {
                sActions +=     "<li>" + getLinkForAction(sActionsPage, actions.ScanWithAllCirDrivenRules.ToString(), sTargetFile, "<b>Scan With All Cir Driven Rules</b>") + "</li>" +
                                "<li>" + getLinkForAction(sActionsPage, actions.ScanWithCallBacksAndSinks.ToString(), sTargetFile, "Scan With Call Backs And Sinks") + "</li>" +
                                "<li>" + getLinkForAction(sActionsPage, actions.CreateCirDataFile.ToString(), sTargetFile, "Create Cir Data File") + "</li>";
            }
            sActions +=         "<li>" + getLinkForAction(sActionsPage, actions.DeleteFile.ToString(), sTargetFile, "DeleteFile") + "</li>" +
                                "</ul>";
            
            return sActions;
        }

        public static String getLink(String sTargetPage, String sLinkText)
        {
            return "<a target=" + config.getActionsLogIFrameName() + " href='" + sTargetPage + "'>" + sLinkText + "</a>";
        }

        public static String getLinkForAction(String sTargetPage, String sActionName, String sFileName, String sLinkText)
        {
            return "<a target=" + config.getActionsLogIFrameName() + " href='" + sTargetPage + "?action=" + sActionName + "&fileName=" + sFileName + "'>" + sLinkText + "</a>";                                    
        }
    }
    
}
