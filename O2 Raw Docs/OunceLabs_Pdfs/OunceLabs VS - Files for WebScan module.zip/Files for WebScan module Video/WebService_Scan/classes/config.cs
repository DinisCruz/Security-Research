﻿using System;
using o2.core;
using System.IO;

namespace o2.webservice_scan.classes
{
    public class config
    {
        public static String getScanResultsFolder()
        {
            return Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"O2WebData\ScanResults"));
        }

        public static String getScanRequestsFolder()
        {
            return Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"O2WebData\ScanRequests"));
        }

        public static String getDevelopersFolder()
        {
            return Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"O2WebData\Developers"));
        }

        public static String getDevelopersUploadedApplicationsFolder()
        {
            return Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(config.getDevelopersFolder(), "UploadedApplications"));
        }

        public static String getDevelopersPublishResultsFolder()
        {
            return Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(config.getDevelopersFolder(), "PublishedResults"));
        }

        public static String getSecurityConsultantFolder()
        {
            return Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"O2WebData\SecurityConsultant"));
        }

        public static String getManagersFolder()
        {
            return Files.checkIfDirectoryExistsAndCreateIfNot(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"O2WebData\Managers"));
        }

        public static String getActionsLogIFrameName()
        {
            return "DeveloperActionsLog";
        }
    }
}