﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using o2.webservice_scan.classes;

namespace o2.webservice_scan
{
    /// <summary>
    /// Summary description for Scan
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Scan : System.Web.Services.WebService
    {

        [WebMethod]
        public string ScanApplication(String sApplicationToScan)
        {
            if (sApplicationToScan == "")
                sApplicationToScan =  @"E:\BlogPosts\TestCases_DotNet\_OunceApplication\dotNet TestCases.paf";
            //String sTestApplication = @"E:\BlogPosts\HacmeBank\_OunceApplication\HacmeBank (just WebServices).paf";
            return new scanproxy().scanApplication(sApplicationToScan, this.Context.Response);
        }
    }
}
