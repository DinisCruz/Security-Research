﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using o2.webservice_scan.classes;
using System.IO;

namespace o2.webservice_scan.WebPages
{
    public partial class SecurityConsultant : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Files.Count > 0)
                securityConsultantActions.processUploadedFiles(Request);
            if (Request["action"] != null && Request["filename"] != null)
            {
                securityConsultantActions.processAction(Request["action"], Request["filename"], Response);
            }
            populateDropDownListWithCurrentProjects();
        }

        private void populateDropDownListWithCurrentProjects()
        { 
             ddlTargetProject.Items.Clear();
             foreach (String sFolder in Directory.GetDirectories(config.getScanResultsFolder()))
                 ddlTargetProject.Items.Add(Path.GetFileName(sFolder));
        }
    }
}
