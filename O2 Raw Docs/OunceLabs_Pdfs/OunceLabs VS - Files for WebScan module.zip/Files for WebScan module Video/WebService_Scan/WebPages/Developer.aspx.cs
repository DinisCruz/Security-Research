﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using o2.webservice_scan.classes;

namespace o2.webservice_scan.WebPages
{
    public partial class Developer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Files.Count > 0)
                developerActions.processUploadedFiles(Request);
            if (Request["action"] != null && Request["filename"] != null)
            {
                developerActions.processAction(Request["action"], Request["filename"], Response);                
            }
        }
    }
}
