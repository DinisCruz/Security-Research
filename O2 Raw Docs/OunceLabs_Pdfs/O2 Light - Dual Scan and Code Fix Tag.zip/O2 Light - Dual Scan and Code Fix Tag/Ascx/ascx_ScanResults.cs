﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using O2.DotNetWrappers.O2Findings;

namespace O2.Light.DualScanAndCodeFix.Ascx
{
    public partial class ascx_ScanResults : UserControl
    {
        public ascx_ScanResults()
        {
            InitializeComponent();
        }

        private void ascx_ScanResults_Load(object sender, EventArgs e)
        {
            BackColor = Color.White;
        }

        private void findingsViewer_Load(object sender, EventArgs e)
        {
            onLoad();
        }

        private void llDiffFindings_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var o2FidingsA = findingsViewerFor_OnlyInAppScanDE.currentO2Findings;
            var o2FidingsB = findingsViewerFor_OnlyInOunce6.currentO2Findings;
            var findingsThatMatch = OzasmtDiff.returnListOfFindingsThatMatch(o2FidingsA, o2FidingsB);
            findingsViewerFor_CommonToBothEngines.loadO2Findings(findingsThatMatch);
        }
    }
}
