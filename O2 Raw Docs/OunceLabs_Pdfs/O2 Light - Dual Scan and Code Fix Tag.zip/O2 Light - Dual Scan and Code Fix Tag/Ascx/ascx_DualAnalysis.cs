﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using O2.DotNetWrappers.DotNet;

namespace O2.Light.DualScanAndCodeFix.Ascx
{
    public partial class ascx_DualAnalysis : UserControl
    {
        public ascx_DualAnalysis()
        {
            InitializeComponent();
        }

        private void ascx_DualAnalysis_Load(object sender, EventArgs e)
        {
            onLoad();
        }

        private void lbEnterTargetProjects_Click(object sender, EventArgs e)
        {
            setCurrentStepLabelsState(0);
        }

        private void lbScanningWithBothEngines_Click(object sender, EventArgs e)
        {
            setCurrentStepLabelsState(1);
        }

        private void lbViewResults_Click(object sender, EventArgs e)
        {
            setCurrentStepLabelsState(2);
        }

        private void splashPage_DragEnter(object sender, DragEventArgs e)
        {
            Dnd.setEffect(e);
        }

        private void splashPage_DragDrop(object sender, DragEventArgs e)
        {
            setCurrentStepLabelsState(1);
            if (e != null)
                scanWithBothEngines.start(Dnd.tryToGetFileOrDirectoryFromDroppedObject(e));
            else
                scanWithBothEngines.start();
        }

        private void pbMainImageAtTop_Click(object sender, EventArgs e)
        {
            splashPage_DragDrop(null, null);
        }


     
        
    }
}