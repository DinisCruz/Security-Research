﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using O2.DotNetWrappers.DotNet;

namespace O2.Light.DualScanAndCodeFix.Ascx
{
    public partial class ascx_SplashPage : UserControl
    {
        public ascx_SplashPage()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void ascx_SplashPage_Load(object sender, EventArgs e)
        {
            BackColor = Color.White;
        }

        private void pbBlueFolderToDropTarget_DragDrop(object sender, DragEventArgs e)
        {

        }

        private void pbBlueFolderToDropTarget_DragEnter(object sender, DragEventArgs e)
        {
            Dnd.setEffect(e);
        }
   
    }
}
