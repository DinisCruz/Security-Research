﻿namespace O2.Light.DualScanAndCodeFix.Ascx
{
    partial class ascx_DualAnalysis
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbEnterTargetProjects = new System.Windows.Forms.Label();
            this.lbScanningWithBothEngines = new System.Windows.Forms.Label();
            this.lbViewResults = new System.Windows.Forms.Label();
            this.pbMainImageAtTop = new System.Windows.Forms.PictureBox();
            this.splashPage = new O2.Light.DualScanAndCodeFix.Ascx.ascx_SplashPage();
            this.scanWithBothEngines = new O2.Light.DualScanAndCodeFix.Ascx.ascx_ScanWithBothEngines();
            this.scanResults = new O2.Light.DualScanAndCodeFix.Ascx.ascx_ScanResults();
            ((System.ComponentModel.ISupportInitialize)(this.pbMainImageAtTop)).BeginInit();
            this.SuspendLayout();
            // 
            // lbEnterTargetProjects
            // 
            this.lbEnterTargetProjects.AutoSize = true;
            this.lbEnterTargetProjects.BackColor = System.Drawing.Color.White;
            this.lbEnterTargetProjects.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEnterTargetProjects.Location = new System.Drawing.Point(392, 21);
            this.lbEnterTargetProjects.Name = "lbEnterTargetProjects";
            this.lbEnterTargetProjects.Size = new System.Drawing.Size(62, 11);
            this.lbEnterTargetProjects.TabIndex = 5;
            this.lbEnterTargetProjects.Text = "enter targets";
            this.lbEnterTargetProjects.Click += new System.EventHandler(this.lbEnterTargetProjects_Click);
            // 
            // lbScanningWithBothEngines
            // 
            this.lbScanningWithBothEngines.AutoSize = true;
            this.lbScanningWithBothEngines.BackColor = System.Drawing.Color.White;
            this.lbScanningWithBothEngines.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbScanningWithBothEngines.Location = new System.Drawing.Point(391, 35);
            this.lbScanningWithBothEngines.Name = "lbScanningWithBothEngines";
            this.lbScanningWithBothEngines.Size = new System.Drawing.Size(136, 11);
            this.lbScanningWithBothEngines.TabIndex = 6;
            this.lbScanningWithBothEngines.Text = "scaning using both engines ";
            this.lbScanningWithBothEngines.Click += new System.EventHandler(this.lbScanningWithBothEngines_Click);
            // 
            // lbViewResults
            // 
            this.lbViewResults.AutoSize = true;
            this.lbViewResults.BackColor = System.Drawing.Color.White;
            this.lbViewResults.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbViewResults.Location = new System.Drawing.Point(392, 48);
            this.lbViewResults.Name = "lbViewResults";
            this.lbViewResults.Size = new System.Drawing.Size(59, 11);
            this.lbViewResults.TabIndex = 7;
            this.lbViewResults.Text = "view results";
            this.lbViewResults.Click += new System.EventHandler(this.lbViewResults_Click);
            // 
            // pbMainImageAtTop
            // 
            this.pbMainImageAtTop.BackgroundImage = global::O2.Light.DualScanAndCodeFix.Properties.Resources.Backgound_AppScan_image;
            this.pbMainImageAtTop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pbMainImageAtTop.Location = new System.Drawing.Point(1, 1);
            this.pbMainImageAtTop.Name = "pbMainImageAtTop";
            this.pbMainImageAtTop.Size = new System.Drawing.Size(645, 284);
            this.pbMainImageAtTop.TabIndex = 3;
            this.pbMainImageAtTop.TabStop = false;
            this.pbMainImageAtTop.Click += new System.EventHandler(this.pbMainImageAtTop_Click);
            // 
            // splashPage
            // 
            this.splashPage.AllowDrop = true;
            this.splashPage.BackColor = System.Drawing.Color.White;
            this.splashPage.Location = new System.Drawing.Point(12, 273);
            this.splashPage.Name = "splashPage";
            this.splashPage.Size = new System.Drawing.Size(616, 272);
            this.splashPage.TabIndex = 8;
            this.splashPage.DragDrop += new System.Windows.Forms.DragEventHandler(this.splashPage_DragDrop);
            this.splashPage.DragEnter += new System.Windows.Forms.DragEventHandler(this.splashPage_DragEnter);
            // 
            // scanWithBothEngines
            // 
            this.scanWithBothEngines.BackColor = System.Drawing.Color.White;
            this.scanWithBothEngines.Location = new System.Drawing.Point(12, 285);
            this.scanWithBothEngines.Name = "scanWithBothEngines";
            this.scanWithBothEngines.Size = new System.Drawing.Size(616, 290);
            this.scanWithBothEngines.TabIndex = 4;
            // 
            // scanResults
            // 
            this.scanResults.BackColor = System.Drawing.Color.White;
            this.scanResults.Location = new System.Drawing.Point(12, 273);
            this.scanResults.Name = "scanResults";
            this.scanResults.Size = new System.Drawing.Size(628, 302);
            this.scanResults.TabIndex = 9;
            // 
            // ascx_DualAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Controls.Add(this.splashPage);
            this.Controls.Add(this.lbViewResults);
            this.Controls.Add(this.lbScanningWithBothEngines);
            this.Controls.Add(this.lbEnterTargetProjects);
            this.Controls.Add(this.scanWithBothEngines);
            this.Controls.Add(this.pbMainImageAtTop);
            this.Controls.Add(this.scanResults);
            this.Name = "ascx_DualAnalysis";
            this.Size = new System.Drawing.Size(643, 607);
            this.Load += new System.EventHandler(this.ascx_DualAnalysis_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbMainImageAtTop)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbMainImageAtTop;
        private ascx_ScanWithBothEngines scanWithBothEngines;
        private System.Windows.Forms.Label lbEnterTargetProjects;
        private System.Windows.Forms.Label lbScanningWithBothEngines;
        private System.Windows.Forms.Label lbViewResults;
        private ascx_SplashPage splashPage;
        private ascx_ScanResults scanResults;
    }
}