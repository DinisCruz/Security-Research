﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using O2.DotNetWrappers.DotNet;

namespace O2.Light.DualScanAndCodeFix.Ascx
{
    public partial class ascx_ScanWithBothEngines : UserControl
    {
        

        public ascx_ScanWithBothEngines()
        {
            InitializeComponent();
        }

        private void ascx_ScanWithBothEngines_Load(object sender, EventArgs e)
        {
            onLoad();
        }

        private void lbWorkflowCompleted_MouseLeave(object sender, EventArgs e)
        {
            lbWorkflowCompleted.Font = new Font(lbWorkflowCompleted.Font, FontStyle.Bold); 
        }

        private void lbWorkflowCompleted_MouseEnter(object sender, EventArgs e)
        {
            lbWorkflowCompleted.Font = new Font(lbWorkflowCompleted.Font, FontStyle.Bold | FontStyle.Underline);            
        }

        private void lbWorkflowCompleted_Click(object sender, EventArgs e)
        {
            setCurrentStepLabelsState(2);
        }

        private void llCancelScan_Ounce6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            cancelCurrentScan();
        }

        private void llCancelScan_AppScan_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            cancelAppScanProcess();
        }

        private void progressBarAppScan_MouseEnter(object sender, EventArgs e)
        {
      //      setScanLogsLabelAndCancelLinkVisibleState(true);
        }

        

        private void progressBarAppScan_MouseLeave(object sender, EventArgs e)
        {
     //       setScanLogsLabelAndCancelLinkVisibleState(false);
        }

        private void progressBarOunce_MouseEnter(object sender, EventArgs e)
        {
            setScanLogsLabelAndCancelLinkVisibleState(! lbScanLog_AppScanDE.Visible);
        }

        private void progressBarOunce_MouseLeave(object sender, EventArgs e)
        {
            //setScanLogsLabelAndCancelLinkVisibleState(false);
        }        
    }
}
