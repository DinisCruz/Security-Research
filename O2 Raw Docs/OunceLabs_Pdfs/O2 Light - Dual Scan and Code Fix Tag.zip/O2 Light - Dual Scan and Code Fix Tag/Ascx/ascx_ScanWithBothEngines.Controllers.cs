﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using O2.DotNetWrappers.DotNet;
using O2.DotNetWrappers.Windows;
using O2.ImportExport.Misc.AppScanDE;
using O2.Kernel.Interfaces.Controllers;
using O2.Kernel.Interfaces.Ozasmt;
using O2.Scanner.OunceLabsCLI.Scan;
using O2.Scanner.OunceLabsCLI.ScanTargets;
using O2.Scanner.OunceLabsCLI.Utils;
using O2.Views.ASCX.O2Findings;

namespace O2.Light.DualScanAndCodeFix.Ascx
{
    partial class ascx_ScanWithBothEngines
    {
        public string testScanTarget = @"E:\IBM\O2 Light - Dual Scan and Code Fix Tag\TestApplication\Test Cases for Software Analyzer";
        public string tempAppScanWorkingDirectory = Path.Combine(DI.config.O2TempDir,"____Temp_AppScan_ScanData");

        public string workDirectory = DI.config.getTempFileInTempDirectory("DUAL_SCAN_RESULTS");
        private bool runOnLoad = true;
        private CliScanning cliScanning;
        private Process appScanDeProcess;

        public ascx_ScanResults scanResults;
        public O2Thread.FuncVoidT1<int> setCurrentStepLabelsState;

        private bool step1Completed = true;
        private bool step2Completed = true;
        private bool step3Completed = true;
        private bool step4Completed = true;
        private bool step5Completed = true;
        private bool step6Completed = true;
        private bool badTick1Visible = false;
        private bool badTick2Visible = false;

        public void onLoad()
        {
            if (runOnLoad)
            {
                BackColor = Color.White;
                runOnLoad = false;
                progressBarAppScan.Maximum = 50;
                progressBarOunce.Maximum = 50;
            }
        }

        public void start()
        {
            start(testScanTarget);
        }

        /*    O2Thread.mtaThread(startDualScanWorkflow);
        }

        private void startDualScanWorkflow()
        {*/

        public void start(string scanTarget)
            {            
            workDirectory = DI.config.getTempFolderInTempDirectory("DUAL_SCAN_RESULTS");

            resetGUI();
            O2Thread.mtaThread(() => scanUsingTheAppScanDeEngine(scanTarget));

            O2Thread.mtaThread(() => scanUsingTheOunceEngine(scanTarget));
            step3Completed = true;

            //step1Completed = true;
            //step2Completed = true;

            updateTickSetVisibleState();

            /*
            int delay = 100;

            Processes.Sleep(delay);
            step1Completed = true;
            setTickSetVisibleState();

            Processes.Sleep(delay);
            step2Completed = true;
            setTickSetVisibleState();

            Processes.Sleep(delay);            
            step3Completed = true;
            setTickSetVisibleState();

            Processes.Sleep(delay);
            step4Completed = true;
            setTickSetVisibleState();

            Processes.Sleep(delay);
            step5Completed = true;
            setTickSetVisibleState();

            Processes.Sleep(delay);
            step6Completed = true;
            setTickSetVisibleState();*/
        }

        public void updateTickSetVisibleState()
        {
            this.invokeOnThread(
                () =>
                    {
                        tickStep1.Visible = step1Completed;
                        tickStep2.Visible = step2Completed;
                        tickStep3.Visible = step3Completed;
                        tickStep4.Visible = step4Completed;
                        tickStep5.Visible = step5Completed;
                        tickStep6.Visible = step6Completed;                        
                        badTick1.Visible = badTick1Visible;
                        badTick2.Visible = badTick2Visible;

                        if (step1Completed && step2Completed && step4Completed == false)
                            startStep4();


                       lbWorkflowCompleted.Visible = (step1Completed && step2Completed && step3Completed && step4Completed && step5Completed && step6Completed);
                    });
        }
        

        public void resetGUI()
        {
            step1Completed = false;
            step2Completed = false;
            step3Completed = false;
            step4Completed = false;
            step5Completed = false;
            step6Completed = false;
            badTick1Visible = false;
            badTick2Visible = false;
            updateTickSetVisibleState();
        }

        public void scanUsingTheAppScanDeEngine(string pathToProcess)
        {
            try
            {
                Files.deleteFolder(tempAppScanWorkingDirectory);
                Files.checkIfDirectoryExistsAndCreateIfNot(tempAppScanWorkingDirectory);

                DI.log.info("target AppScan results directory :{0}", tempAppScanWorkingDirectory);
                setProgressBarValue(progressBarAppScan, true);
                appScanDeProcess = new AppScanDE_Scanner().executeAppScanDEScan(pathToProcess, tempAppScanWorkingDirectory,
                                                                                onAppScanLogEvent);
                //appScanDeProcess.Exited += appScanDeProcess_Exited;
                // need to do this since the Exited event is not firing reliably 100% of the time
                while (false == appScanDeProcess.HasExited)
                {
                    Processes.Sleep(1000,false);
                }

                if (Files.getListOfAllDirectoriesFromDirectory(tempAppScanWorkingDirectory,false).Count() > 0)
                {
                    step1Completed = true;
                    badTick1Visible = false;
                    var appScanDELoaded = new O2AssesmentLoad_AppScanDE();
                    var o2Assessment = appScanDELoaded.loadFile(tempAppScanWorkingDirectory);
                    scanResults.loadFindingsFor_OnlyInAppScanDe(o2Assessment.o2Findings);
                }
                else
                {
                    badTick1Visible = true;
                }

                setProgressBarValue(progressBarAppScan, false);

                //badTick1Visible = true;
                updateTickSetVisibleState();
            }
            catch (Exception ex)
            {
                DI.log.error("in scanUsingTheAppScanDeEngine: {0}", ex.Message);
                throw;
            }
        }

        

        public void scanUsingTheOunceEngine(string pathToProcess)
        {
            setProgressBarValue(progressBarOunce, true);
            var pafFiles = Files.getFilesFromDir_returnFullPath(pathToProcess, "*.paf", true);
            if (pafFiles.Count != 1)
            {
                DI.log.error(
                    "in scanUsingTheOunceEngine , there there be only 1 target *.paf file, and there were {0}",
                    pafFiles.Count);
                badTick2Visible = true;
                updateTickSetVisibleState();
            }
            else
            {
                var scanTarget = new ScanTarget_Paf
                                     {
                                         useFileNameOnWorkDirecory = false,
                                         WorkDirectory = workDirectory,
                                         Target = pafFiles[0]
                                     };
                scanApplication(scanTarget);

            }
        }

        public void scanApplication(IScanTarget scanTarget)
        {
            string sSaveAssessmentTo = Path.Combine(scanTarget.WorkDirectory,
                                                    Path.GetFileNameWithoutExtension(
                                                        scanTarget.ApplicationFile) +
                                                    "_Scan_CurrentRules.ozasmt");

            DI.log.debug("Saved Assessment File will be saved to : {0}", sSaveAssessmentTo);            
            
            cliScanning = new CliScanning();
            // start scanning
            cliScanning.scanApplication(scanTarget.ApplicationFile, sSaveAssessmentTo,
                                       onOunceScanLogEvent
                                                                                                ,
                                        scanResult => onOunceScanCompleted(sSaveAssessmentTo));
        }

        private void onOunceScanLogEvent(string logEntry)
        {
            this.invokeOnThread
                (() =>
                     {
                         lbScanLog_Ounce6.Text = logEntry;
                         DI.log.info(logEntry);
                         incProgressBarForOunce();
                     });
        }

        private void onOunceScanCompleted(string savedAssessmentPath)
        {
            this.invokeOnThread(
                () =>
                    {
                        lbScanLog_Ounce6.Text = "Scan Completed ";
                        step2Completed = true;                        
                        setProgressBarValue(progressBarOunce, false);
                        updateTickSetVisibleState();
                        scanResults.loadFindingsFor_OnlyInOunce6(savedAssessmentPath);
                        //btScan.Text = scanButton_ScanText;
                        //ascx_FindingsViewer.openInFloatWindow(savedAssessmentPath);
                    }); 
        }

        private void cancelCurrentScan()
        {
            if (cliScanning != null)
            {
                cliScanning.cancelScan();                
                this.invokeOnThread (() => lbScanLog_Ounce6.Text = "Ounce 6.x scan canceled" );                
                step2Completed = false;
                badTick2Visible = true;
                setProgressBarValue(progressBarOunce, false);
                updateTickSetVisibleState();
            }
        }

        private void cancelAppScanProcess()
        {
            if (appScanDeProcess != null)
            {
                appScanDeProcess.Kill();
                this.invokeOnThread(() => lbScanLog_Ounce6.Text = "AppScan scan canceled");
                setProgressBarValue(progressBarAppScan, false);
            }
        }

        private void onAppScanLogEvent(object sender, DataReceivedEventArgs e)
        {
            this.invokeOnThread
                (() =>
                     {
                         if (e.Data != null)
                         {
                             lbScanLog_AppScanDE.Text = e.Data;
                             DI.log.info(e.Data);
                         }
                         incProgressBarForAppScan();
                     });                
        }     

        public void incProgressBarForOunce()
        {
            incProgressBar(progressBarOunce);
        }

        public void incProgressBarForAppScan()
        {
            incProgressBar(progressBarAppScan);
        }

        public void incProgressBar(ProgressBar progressBar)
        {
            progressBar.invokeOnThread(
                () =>
                    {
                        if (progressBar.Value == progressBar.Maximum)
                            progressBar.Value = 0;
                        progressBar.Value++;
                    }
                );
        }

        public void setProgressBarValue(ProgressBar progressBar, bool setAtZeroVsSetAtMaximum)
        {
            progressBar.invokeOnThread(
                () =>
                    {
                        progressBar.Value = (setAtZeroVsSetAtMaximum) ? 0 : progressBar.Maximum;
                    });
        }

        private void startStep4()
        {
            O2Thread.mtaThread(
                () =>
                    {
                        if (step4Completed == false)
                        {
                            var o2AssessmentFor_AppScan =
                                new O2AssesmentLoad_AppScanDE().loadFile(tempAppScanWorkingDirectory);
                            step4Completed = true;
                            updateTickSetVisibleState();
                            startStep5(o2AssessmentFor_AppScan, null);
                        }
                    });

        }

        private void startStep5(IO2Assessment o2AssessmentFor_AppScan, IO2Assessment o2AssessmentFor_Ounce)
        {
            O2Thread.mtaThread(
                () =>
                    {
                        if (step5Completed == false)
                        {
                            Processes.Sleep(500);
                            step5Completed = true;
                            updateTickSetVisibleState();
                            startStep6(o2AssessmentFor_AppScan.o2Findings, null,null);
                        }
                    });
        }

        private void startStep6(List<IO2Finding> consolidadedFildings,List<IO2Finding> fidingsOnlyInOunce6, List<IO2Finding>findingsOnlyInAppScan)
        {
            O2Thread.mtaThread(
                () =>
                    {
                        if (step6Completed == false)
                        {
                            Processes.Sleep(500);
                            scanResults.showFindingsThatMatch(consolidadedFildings, fidingsOnlyInOunce6, findingsOnlyInAppScan);
                            step6Completed = true;
                            updateTickSetVisibleState();
                        }
                    });
        }

        private void setScanLogsLabelAndCancelLinkVisibleState(bool value)
        {
            llCancelScan_AppScan.Visible = value;
            llCancelScan_Ounce6.Visible = value;

            lbScanLog_AppScanDE.Visible = value;
            lbScanLog_Ounce6.Visible = value;
        }
    }
}
