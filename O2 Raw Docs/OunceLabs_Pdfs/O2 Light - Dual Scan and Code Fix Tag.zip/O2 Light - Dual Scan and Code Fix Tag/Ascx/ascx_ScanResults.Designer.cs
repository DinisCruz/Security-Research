﻿namespace O2.Light.DualScanAndCodeFix.Ascx
{
    partial class ascx_ScanResults
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.findingsViewerFor_CommonToBothEngines = new O2.Views.ASCX.O2Findings.ascx_FindingsViewer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.findingsViewerFor_OnlyInOunce6 = new O2.Views.ASCX.O2Findings.ascx_FindingsViewer();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.findingsViewerFor_OnlyInAppScanDE = new O2.Views.ASCX.O2Findings.ascx_FindingsViewer();
            this.llShowOrHideFindingsViews = new System.Windows.Forms.LinkLabel();
            this.llDiffFindings = new System.Windows.Forms.LinkLabel();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 30);
            this.label1.TabIndex = 32;
            this.label1.Text = "Scan Results";
            // 
            // findingsViewerFor_CommonToBothEngines
            // 
            this.findingsViewerFor_CommonToBothEngines.Dock = System.Windows.Forms.DockStyle.Fill;
            this.findingsViewerFor_CommonToBothEngines.Location = new System.Drawing.Point(3, 3);
            this.findingsViewerFor_CommonToBothEngines.Name = "findingsViewerFor_CommonToBothEngines";
            this.findingsViewerFor_CommonToBothEngines.Size = new System.Drawing.Size(486, 205);
            this.findingsViewerFor_CommonToBothEngines.TabIndex = 33;
            this.findingsViewerFor_CommonToBothEngines.Load += new System.EventHandler(this.findingsViewer_Load);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(7, 44);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(500, 237);
            this.tabControl1.TabIndex = 34;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.findingsViewerFor_CommonToBothEngines);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(492, 211);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Findings Common to Both Engine";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.findingsViewerFor_OnlyInOunce6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(492, 211);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Findings only in Ounce 6.x";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // findingsViewerFor_OnlyInOunce6
            // 
            this.findingsViewerFor_OnlyInOunce6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.findingsViewerFor_OnlyInOunce6.Location = new System.Drawing.Point(3, 3);
            this.findingsViewerFor_OnlyInOunce6.Name = "findingsViewerFor_OnlyInOunce6";
            this.findingsViewerFor_OnlyInOunce6.Size = new System.Drawing.Size(486, 205);
            this.findingsViewerFor_OnlyInOunce6.TabIndex = 34;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.findingsViewerFor_OnlyInAppScanDE);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(492, 211);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Findings only in AppScan DE";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // findingsViewerFor_OnlyInAppScanDE
            // 
            this.findingsViewerFor_OnlyInAppScanDE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.findingsViewerFor_OnlyInAppScanDE.Location = new System.Drawing.Point(0, 0);
            this.findingsViewerFor_OnlyInAppScanDE.Name = "findingsViewerFor_OnlyInAppScanDE";
            this.findingsViewerFor_OnlyInAppScanDE.Size = new System.Drawing.Size(492, 211);
            this.findingsViewerFor_OnlyInAppScanDE.TabIndex = 34;
            // 
            // llShowOrHideFindingsViews
            // 
            this.llShowOrHideFindingsViews.AutoSize = true;
            this.llShowOrHideFindingsViews.Location = new System.Drawing.Point(150, 16);
            this.llShowOrHideFindingsViews.Name = "llShowOrHideFindingsViews";
            this.llShowOrHideFindingsViews.Size = new System.Drawing.Size(0, 13);
            this.llShowOrHideFindingsViews.TabIndex = 35;
            this.llShowOrHideFindingsViews.Visible = false;
            // 
            // llDiffFindings
            // 
            this.llDiffFindings.AutoSize = true;
            this.llDiffFindings.Location = new System.Drawing.Point(281, 16);
            this.llDiffFindings.Name = "llDiffFindings";
            this.llDiffFindings.Size = new System.Drawing.Size(0, 13);
            this.llDiffFindings.TabIndex = 37;
            this.llDiffFindings.Visible = false;
            this.llDiffFindings.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llDiffFindings_LinkClicked);
            // 
            // ascx_ScanResults
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Controls.Add(this.llDiffFindings);
            this.Controls.Add(this.llShowOrHideFindingsViews);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Name = "ascx_ScanResults";
            this.Size = new System.Drawing.Size(520, 284);
            this.Load += new System.EventHandler(this.ascx_ScanResults_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private O2.Views.ASCX.O2Findings.ascx_FindingsViewer findingsViewerFor_CommonToBothEngines;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private O2.Views.ASCX.O2Findings.ascx_FindingsViewer findingsViewerFor_OnlyInOunce6;
        private System.Windows.Forms.TabPage tabPage3;
        private O2.Views.ASCX.O2Findings.ascx_FindingsViewer findingsViewerFor_OnlyInAppScanDE;
        private System.Windows.Forms.LinkLabel llShowOrHideFindingsViews;
        private System.Windows.Forms.LinkLabel llDiffFindings;
    }
}
