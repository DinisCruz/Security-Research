﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace O2.Light.DualScanAndCodeFix.Ascx
{
	partial class ascx_DualAnalysis
	{
	    private bool runOnLoad = true;

        public void onLoad()
        {
            if (false == DesignMode && runOnLoad)
            {
                BackColor = Color.White;                
                setCurrentStepLabelsState(0);
                scanWithBothEngines.setCurrentStepLabelsState = setCurrentStepLabelsState;
                scanWithBothEngines.scanResults = scanResults;
                runOnLoad = false;
            }
        }

        public void setCurrentStepLabelsState(int currentLabel)
        {
            lbEnterTargetProjects.ForeColor = Color.DarkGray;
            lbScanningWithBothEngines.ForeColor = Color.DarkGray;
            lbViewResults.ForeColor = Color.DarkGray;
            scanWithBothEngines.Visible = false;
            splashPage.Visible = false;
            scanResults.Visible = false;

            switch (currentLabel)
            {
                case 0:
                    lbEnterTargetProjects.ForeColor = Color.Black;
                    splashPage.Visible = true;
                    break;
                case 1:
                    lbScanningWithBothEngines.ForeColor = Color.Black;
                    scanWithBothEngines.Visible = true;
                    break;
                case 2:
                    lbViewResults.ForeColor = Color.Black;
                    scanResults.Visible = true;
                    break;
            }
        }
	}
}
