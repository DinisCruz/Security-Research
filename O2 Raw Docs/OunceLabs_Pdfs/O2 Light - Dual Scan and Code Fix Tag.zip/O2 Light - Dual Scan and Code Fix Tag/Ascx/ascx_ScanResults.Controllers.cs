﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using O2.DotNetWrappers.O2Findings;
using O2.ImportExport.OunceLabs.Ozasmt_OunceV6;
using O2.Kernel.Interfaces.Ozasmt;

namespace O2.Light.DualScanAndCodeFix.Ascx
{
    partial class ascx_ScanResults
    {

        private bool runOnLoad = true;

        public void onLoad()
        {
            if (false == DesignMode && runOnLoad)
            {
                runOnLoad = false;                
            }
        }

        public void loadFindingsFor_ComonToBothEngines(List<IO2Finding> o2Findings)
        {
            findingsViewerFor_CommonToBothEngines.loadO2Findings(o2Findings);
        }

        public void loadFindingsFor_OnlyInOunce6(List<IO2Finding> o2Findings)
        {
            findingsViewerFor_OnlyInOunce6.loadO2Findings(o2Findings);
        }

        public void loadFindingsFor_OnlyInAppScanDe(List<IO2Finding> o2Findings)
        {
            findingsViewerFor_OnlyInAppScanDE.loadO2Findings(o2Findings);
        }

        internal void calculateAndShowFindingsThatMatch(List<IO2Finding> consolidadedFildings)
        {
            throw new NotImplementedException();
        }

        internal void showFindingsThatMatch(List<IO2Finding> commonToBothEngines, List<IO2Finding> fidingsOnlyInOunce6, List<IO2Finding> findingsOnlyInAppScan)
        {
            loadFindingsFor_ComonToBothEngines(commonToBothEngines);
            loadFindingsFor_OnlyInAppScanDe(findingsOnlyInAppScan);
            loadFindingsFor_OnlyInOunce6(fidingsOnlyInOunce6);
            
        }

        internal void loadFindingsFor_OnlyInOunce6(string savedAssessmentPath)
        {
            try
            {
                var o2Assessment = new O2Assessment(new O2AssessmentLoad_OunceV6(), savedAssessmentPath);
                loadFindingsFor_OnlyInOunce6(o2Assessment.o2Findings);
            }
            catch (Exception ex)
            {
                DI.log.error("in loadFindingsFor_OnlyInOunce6: {0}", ex.Message);
            }
            
        }
    }
}   
