﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using O2.External.WinFormsUI.Forms;
using O2.ImportExport.Misc.AppScanDE;
using O2.ImportExport.OunceLabs.Ozasmt_OunceV6;
using O2.Kernel.Interfaces.Ozasmt;
using O2.Light.DualScanAndCodeFix.Ascx;
using O2.Views.ASCX.O2Findings;

namespace O2.Light.DualScanAndCodeFix
{
    static class Program
    {
        static void Main()
        {
            ascx_FindingsViewer.addO2AssessmentLoadEngine_static(new O2AssesmentLoad_AppScanDE());
            ascx_FindingsViewer.addO2AssessmentLoadEngine_static(new O2AssessmentLoad_OunceV6());

            O2AscxGUI.openAscxAsForm(typeof(ascx_DualAnalysis),"O2 Light - Dual Scan and Code Fix Tag");
            /*if (O2AscxGUI.launch("O2 Light - Dual Analysis"))
            {
                O2AscxGUI.openAscx(typeof (ascx_DualAnalysis));
            }*/
        }
    }    
}