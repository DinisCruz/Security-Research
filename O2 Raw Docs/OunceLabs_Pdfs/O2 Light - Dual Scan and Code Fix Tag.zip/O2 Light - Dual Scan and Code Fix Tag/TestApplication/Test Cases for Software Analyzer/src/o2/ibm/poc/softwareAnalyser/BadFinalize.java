package o2.ibm.poc.softwareAnalyser;

public class BadFinalize {

	private void method() {
        // Do something
    }

    // Don't do this
    protected  void finalize()  throws Throwable {
    	super.finalize();
    }
}
