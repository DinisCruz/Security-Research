package o2.ibm.poc.softwareAnalyser;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetParameterPoC {

	public void handleRequest( HttpServletRequest request, HttpServletResponse response ) throws IOException
	{		
		String firstName = request.getParameter("firstName");
		response.getWriter().write(firstName);		
		String secondName = request.getParameter("firstName....");
	}
}
